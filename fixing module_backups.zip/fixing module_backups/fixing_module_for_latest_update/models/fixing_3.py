# -*- coding: utf-8 -*-
import datetime

from odoo import api, models, fields, _
from odoo.exceptions import UserError


class MasterAndOtherDateFix(models.Model):
    _inherit = 'pemt.rec'

    # @api.multi

    def latest_update(self):
        self.check_admin_user_2()

    def check_admin_user_2(self):
        flag = self.env['res.users'].has_group('base.group_system')
        if flag:
            self.latest_update_to_true()
        else:
            raise UserError('You are not allowed to use this action')

    def latest_update_to_true(self):
        lir = 0
        for recs in self:
            print(recs)
            if recs.try_lines:
                print(recs.try_lines[-1])
                recs.try_lines[-1].latest = True
                lir += 1
            else:
                recs.latest = True
        print(lir)
