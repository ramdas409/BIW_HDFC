{
    "name": "Fixation Module 3",
    "version": "15.0.2",
    "summary": "Fixing module for latest update",
    "category": "Fixation",
    "author": "Suprit S",
    "depends": ['multiple_order_process', 'base'],
    "data": [
        "views/fixing_3.xml"
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}